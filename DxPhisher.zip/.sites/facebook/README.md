# Facebook Static Login Form (Full offline css and js)

## Author: [KasRoudra](https://github.com/KasRoudra)

#### This is created for educational purposes demonstrating how phishing works.

### Use/Copy it legally and provide proper credit